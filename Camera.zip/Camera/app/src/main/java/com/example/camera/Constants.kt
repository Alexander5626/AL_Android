package com.example.camera

object Constants {
    val REQUEST_CODE_PERMISSIONS: Int
    const val TAG = "camera"
    const val FILE_NAME_FORMAT = "yy-MM-dd-HH-mm--ss-SSS"
    const val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION)
}